//! LiteMiner H, client half: hold Left Alt (or tap it, on the settings page's Tap mode) and the
//! blocks a mined block would bring down are outlined, with what it costs in a panel: blocks,
//! hunger and the tool's durability. The mouse wheel, while the key is held, switches the
//! shape. It arms the server half (`/lite arm ...`, quietly, every half second) and the server
//! half mines them as the player.
#[path = "../../shared/planner.rs"]
mod planner;
use horizon_mod_sdk::render::{self, Corner, FillShape, ItemShape, Outline, Point, Rect, Shape as Draw, TextShape};
use horizon_mod_sdk::ui::{self, ButtonWidget, TextWidget, Widget};
use horizon_mod_sdk::{command, game, input, storage, Mod, Registration};
use planner::{face_name, facing, plan, Pos, Shape, MAX};

const SETTINGS: &str = "settings";
/// How far ahead the preview looks for the block to mine (survival reach is 4.5).
const REACH: f32 = 5.0;
/// Ticks between arms while held, and between previews of an unchanged target.
const PULSE: u64 = 10;
/// Vanilla's exhaustion per block a player mines (`Block.playerDestroy`); 4 is a food point.
const EXHAUSTION: f32 = 0.005;
const LIMITS: [u32; 6] = [8, 16, 24, 32, 48, 64];
const COLORS: [(&str, u32); 5] = [
    ("Sky", 0xFF7F_B2FF),
    ("Mint", 0xFF6E_F0B4),
    ("Gold", 0xFFFF_C857),
    ("Rose", 0xFFFF_7A9C),
    ("White", 0xFFF2_F4FF),
];
const CORNERS: [&str; 5] = ["Top left", "Top right", "Bottom left", "Bottom right", "Off"];
const OUTLINES: [&str; 3] = ["Through blocks", "Visible faces", "Off"];

#[derive(Clone, Copy, Debug, PartialEq)]
struct Settings {
    shape: Shape,
    limit: u32,
    /// Hold the key (true) or tap it on and off.
    hold: bool,
    outline: usize,
    color: usize,
    corner: usize,
}
impl Default for Settings {
    fn default() -> Self {
        Settings { shape: Shape::Vein, limit: MAX as u32, hold: true, outline: 0, color: 0, corner: 1 }
    }
}
impl Settings {
    fn read(text: &str) -> Settings {
        let mut s = Settings::default();
        for pair in text.split_whitespace() {
            let Some((k, v)) = pair.split_once('=') else { continue };
            let n = v.parse::<usize>().ok();
            match k {
                "shape" => s.shape = Shape::parse(v).unwrap_or(s.shape),
                "limit" => s.limit = v.parse::<u32>().map_or(s.limit, |l| l.clamp(1, MAX as u32)),
                "hold" => s.hold = v != "0",
                "outline" => s.outline = n.filter(|&n| n < OUTLINES.len()).unwrap_or(s.outline),
                "color" => s.color = n.filter(|&n| n < COLORS.len()).unwrap_or(s.color),
                "corner" => s.corner = n.filter(|&n| n < CORNERS.len()).unwrap_or(s.corner),
                _ => {}
            }
        }
        s
    }
    fn write(&self) -> String {
        format!(
            "shape={} limit={} hold={} outline={} color={} corner={}",
            self.shape.name(),
            self.limit,
            u8::from(self.hold),
            self.outline,
            self.color,
            self.corner
        )
    }
}

/// What mining the target would cost: (blocks, food points, durability uses, uses left).
struct Cost {
    blocks: usize,
    food: f32,
    wear: Option<(u32, u32, u32)>,
}
fn cost(blocks: usize, durability: Option<(u32, u32, u32)>) -> Cost {
    Cost {
        blocks,
        food: blocks as f32 * EXHAUSTION / 4.0,
        // Each block costs a use; Unbreaking spares (level / (level + 1)) of them on average.
        wear: durability.map(|(left, _max, unbreaking)| {
            let uses = blocks as u32;
            (uses, uses.div_ceil(unbreaking + 1), left)
        }),
    }
}

struct Preview {
    origin: Pos,
    block: String,
    blocks: Vec<Pos>,
    key: (Shape, u32, Pos),
    at: u64,
}

#[derive(Default)]
struct Client {
    s: Settings,
    active: bool,
    wheel: bool,
    last_arm: u64,
    sent: Option<(Shape, u32, Pos)>,
    preview: Option<Preview>,
    shown: bool,
}

impl Client {
    fn save(&self) {
        let _ = storage::set(SETTINGS, self.s.write().as_bytes());
    }
    fn clear(&mut self) {
        if self.shown {
            render::set_outlines(&[]);
            render::clear_corner();
            self.shown = false;
        }
        self.preview = None;
    }
    fn arm(&mut self, tick: u64, forward: Pos) {
        let key = (self.s.shape, self.s.limit, forward);
        if self.sent != Some(key) || tick.saturating_sub(self.last_arm) >= PULSE {
            let line = format!("lite arm {} {} {}", key.0.name(), key.1, face_name(forward));
            command::run_quiet(&[line]);
            self.sent = Some(key);
            self.last_arm = tick;
        }
    }
    fn disarm(&mut self) {
        if self.sent.take().is_some() {
            command::run_quiet(&["lite disarm".to_string()]);
        }
    }
    /// The blocks the target would bring down, planned again when it or the shape changed, or
    /// every half second (the world changes).
    fn plan(&mut self, tick: u64, forward: Pos) {
        let Some(hit) = game::raycast(REACH) else {
            self.preview = None;
            return;
        };
        let origin = Pos(hit.block_x, hit.block_y, hit.block_z);
        let key = (self.s.shape, self.s.limit, forward);
        if let Some(p) = &self.preview
            && p.origin == origin
            && p.key == key
            && p.block == hit.block
            && tick.saturating_sub(p.at) < PULSE
        {
            return;
        }
        let mut blocks = vec![origin];
        if !planner::kept(&hit.block) {
            blocks.extend(plan(origin, &hit.block, key.0, key.1 as usize, forward, |p| {
                game::get_block(p.0, p.1, p.2)
            }));
        }
        self.preview = Some(Preview { origin, block: hit.block, blocks, key, at: tick });
    }
    fn draw(&mut self) {
        let color = COLORS[self.s.color].1;
        let outlines: Vec<Outline> = match (&self.preview, self.s.outline) {
            (Some(p), 0 | 1) => p
                .blocks
                .iter()
                .map(|b| Outline { x: b.0, y: b.1, z: b.2, color, through: self.s.outline == 0 })
                .collect(),
            _ => Vec::new(),
        };
        render::set_outlines(&outlines);
        if self.s.corner < 4 {
            let corner = [Corner::TopLeft, Corner::TopRight, Corner::BottomLeft, Corner::BottomRight][self.s.corner];
            let durability = input::held_durability().map(|d| (d.left, d.max, d.unbreaking));
            let (w, h, shapes) = panel(self.s.shape, self.s.limit, self.s.hold, color, self.preview.as_ref(), durability);
            render::set_corner(corner, w, h, &shapes);
        } else {
            render::clear_corner();
        }
        self.shown = true;
    }
    fn widgets(&self) -> Vec<Widget> {
        let text = |id, text: &str, color| Widget::Text(TextWidget { id, text: text.into(), color });
        let button = |id, label: String| Widget::Button(ButtonWidget { id, label });
        vec![
            text(0, "LiteMiner H 0.3", 0x9DB7FF),
            text(10, "Hold Left Alt and mine a block: the outlined blocks come down too, mined", 0),
            text(11, "with your tool. While holding, scroll to switch the shape. The keys are", 0),
            text(12, "on this page's Key Binds rows; on a phone, add a touch button for them.", 0),
            button(1, format!("Shape: {}", self.s.shape.label())),
            button(2, format!("Block limit: {}", self.s.limit)),
            button(3, format!("Activation: {}", if self.s.hold { "Hold the key" } else { "Tap on, tap off" })),
            button(4, format!("Outline: {}", OUTLINES[self.s.outline])),
            button(5, format!("Outline colour: {}", COLORS[self.s.color].0)),
            button(6, format!("Stats panel: {}", CORNERS[self.s.corner])),
            text(13, "The server half (liteminer.hmod) must be on where the world runs.", 0xA0A8C0),
        ]
    }
}

/// The stats panel's size and shapes.
fn panel(
    shape: Shape,
    limit: u32,
    hold: bool,
    accent: u32,
    preview: Option<&Preview>,
    durability: Option<(u32, u32, u32)>,
) -> (f32, f32, Vec<Draw>) {
    let (w, h) = (156.0, 66.0);
    let fill = |x, y, w, h, color| Draw::Fill(FillShape { rect: Rect { x, y, w, h }, color });
    let text = |x, y, t: String, color| {
        Draw::Text(TextShape { text: t, at: Point { x, y }, color, centered: false, shadow: true })
    };
    let rgb = accent & 0xFF_FFFF;
    let mut shapes = vec![
        fill(0.0, 0.0, w, h, 0xD80E_1424),
        fill(0.0, 0.0, 2.0, h, accent),
        fill(2.0, 13.0, w - 2.0, 1.0, 0x6026_365F),
        text(6.0, 3.0, format!("LiteMiner · {}", shape.label()), rgb),
    ];
    if hold {
        let width = render::text_width("scroll");
        shapes.push(text(w - width - 5.0, 3.0, "scroll".into(), 0x7080A0));
    }
    let Some(p) = preview else {
        shapes.push(text(6.0, 20.0, "Look at a block to mine".into(), 0xB0B8D0));
        return (w, h, shapes);
    };
    let item = p.block.split('[').next().unwrap_or(&p.block).to_string();
    shapes.push(Draw::Item(ItemShape { item, at: Point { x: 5.0, y: 18.0 }, scale: 1.0 }));
    let c = cost(p.blocks.len(), durability);
    let row = |y: f32, label: &str, value: String, color: u32| {
        [text(26.0, y, label.into(), 0xA0A8C0), text(86.0, y, value, color)]
    };
    shapes.extend(row(17.0, "Blocks", format!("{} / {limit}", c.blocks), 0xFFFFFF));
    shapes.extend(row(28.0, "Hunger", format!("-{:.2}", c.food), 0xFFD27F));
    match c.wear {
        Some((uses, expected, left)) => {
            let value = if expected < uses { format!("-{expected} (~)") } else { format!("-{uses}") };
            let short = expected >= left;
            shapes.extend(row(39.0, "Durability", value, if short { 0xFF6B6B } else { 0x9DE8B0 }));
            let note = if short {
                format!("Breaks after {left} blocks")
            } else {
                format!("{left} uses left")
            };
            shapes.push(text(26.0, 51.0, note, if short { 0xFF6B6B } else { 0x7080A0 }));
        }
        None => shapes.extend(row(39.0, "Durability", "no tool".into(), 0x7080A0)),
    }
    (w, h, shapes)
}

impl Mod for Client {
    fn init() -> Result<(Self, Registration), String> {
        input::register_key("mine", "Hold to vein mine", "key.keyboard.left.alt")?;
        input::register_key("shape", "Next shape", "key.keyboard.grave.accent")?;
        let saved = storage::get(SETTINGS).unwrap_or_default();
        let client = Client { s: Settings::read(&String::from_utf8_lossy(&saved)), ..Default::default() };
        Ok((client, Registration::new().on_tick()))
    }

    fn tick(&mut self, tick: u64) {
        let mut changed = false;
        for event in input::poll() {
            match event {
                input::Event::KeyDown(name) if name == "mine" => {
                    self.active = if self.s.hold { true } else { !self.active };
                }
                input::Event::KeyUp(name) if name == "mine" && self.s.hold => self.active = false,
                input::Event::KeyDown(name) if name == "shape" => {
                    self.s.shape = self.s.shape.step(1);
                    changed = true;
                }
                // Away from the player (up) is the shape before, as the hotbar's.
                input::Event::Wheel(steps) if self.wheel && steps != 0.0 => {
                    self.s.shape = self.s.shape.step(if steps > 0.0 { -1 } else { 1 });
                    changed = true;
                }
                _ => {}
            }
        }
        if changed {
            self.save();
        }
        let wheel = self.active && self.s.hold;
        if wheel != self.wheel {
            input::claim_wheel(wheel);
            self.wheel = wheel;
        }
        let player = game::get_player().filter(|_| self.active);
        let Some(player) = player else {
            self.disarm();
            self.clear();
            return;
        };
        let forward = facing(player.yaw, player.pitch);
        self.arm(tick, forward);
        self.plan(tick, forward);
        self.draw();
    }

    fn ui_settings_opened(&mut self) {
        ui::set_settings(&self.widgets());
    }

    fn ui_select(&mut self, id: u32, _row: u32) {
        let s = &mut self.s;
        match id {
            1 => s.shape = s.shape.step(1),
            2 => {
                let i = LIMITS.iter().position(|&l| l == s.limit).map_or(0, |i| (i + 1) % LIMITS.len());
                s.limit = LIMITS[i];
            }
            3 => s.hold = !s.hold,
            4 => s.outline = (s.outline + 1) % OUTLINES.len(),
            5 => s.color = (s.color + 1) % COLORS.len(),
            6 => s.corner = (s.corner + 1) % CORNERS.len(),
            _ => return,
        }
        // Tap mode leaves it armed until tapped again; switching to Hold ends that.
        if id == 3 {
            self.active = false;
        }
        self.save();
        ui::set_settings(&self.widgets());
    }
}

horizon_mod_sdk::export_mod!(Client);

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn settings_survive_storage() {
        let s = Settings { shape: Shape::Line, limit: 24, hold: false, outline: 2, color: 3, corner: 4 };
        assert_eq!(Settings::read(&s.write()), s);
        // Unknown and out-of-range values keep the defaults.
        assert_eq!(Settings::read("limit=999 color=9 shape=nope"), Settings { limit: 64, ..Settings::default() });
    }

    #[test]
    fn costs_follow_vanilla() {
        // 64 blocks: 0.32 exhaustion, 0.08 of a food point; Unbreaking III spares 3 in 4 uses.
        let c = cost(64, Some((100, 1561, 3)));
        assert!((c.food - 0.08).abs() < 1e-6);
        assert_eq!(c.wear, Some((64, 16, 100)));
        assert_eq!(cost(5, None).wear, None);
    }
}
