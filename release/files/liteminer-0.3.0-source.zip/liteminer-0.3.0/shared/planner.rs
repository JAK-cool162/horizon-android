//! The blocks LiteMiner H mines with the one the player broke: pure, shared by the client half
//! (its preview) and the server half (what it mines), with unit tests. Each half uses part of it.
#![allow(dead_code)]
use std::collections::{BTreeSet, VecDeque};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct Pos(pub i32, pub i32, pub i32);
impl Pos {
    fn plus(self, o: Pos) -> Pos {
        Pos(self.0 + o.0, self.1 + o.1, self.2 + o.2)
    }
    fn times(self, n: i32) -> Pos {
        Pos(self.0 * n, self.1 * n, self.2 * n)
    }
    fn near(self, other: Pos) -> bool {
        (self.0 - other.0).abs() <= REACH
            && (self.1 - other.1).abs() <= REACH
            && (self.2 - other.2).abs() <= REACH
    }
}

/// How far from the first block a vein is followed, per axis.
pub const REACH: i32 = 16;
/// The most blocks, the first one included.
pub const MAX: usize = 64;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Shape {
    /// The connected blocks of the same kind, diagonals included.
    Vein,
    /// 3 x 3 across the face mined.
    Plane,
    /// 3 x 3, as deep as the limit allows.
    Tunnel,
    /// One block wide and high, straight ahead.
    Line,
    StairsUp,
    StairsDown,
}
impl Shape {
    pub const ALL: [Shape; 6] = [
        Shape::Vein,
        Shape::Plane,
        Shape::Tunnel,
        Shape::Line,
        Shape::StairsUp,
        Shape::StairsDown,
    ];
    pub fn name(self) -> &'static str {
        match self {
            Shape::Vein => "vein",
            Shape::Plane => "plane",
            Shape::Tunnel => "tunnel",
            Shape::Line => "line",
            Shape::StairsUp => "stairsup",
            Shape::StairsDown => "stairsdown",
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            Shape::Vein => "Vein",
            Shape::Plane => "3x3 plane",
            Shape::Tunnel => "3x3 tunnel",
            Shape::Line => "Line",
            Shape::StairsUp => "Stairs up",
            Shape::StairsDown => "Stairs down",
        }
    }
    pub fn parse(text: &str) -> Option<Shape> {
        match text.to_ascii_lowercase().as_str() {
            "vein" | "connected" => Some(Shape::Vein),
            "plane" | "3x3" => Some(Shape::Plane),
            "tunnel" => Some(Shape::Tunnel),
            "line" | "1x1" => Some(Shape::Line),
            "stairsup" | "up" => Some(Shape::StairsUp),
            "stairsdown" | "down" => Some(Shape::StairsDown),
            _ => None,
        }
    }
    /// The next shape (`steps` may be negative), round the list.
    pub fn step(self, steps: i32) -> Shape {
        let n = Shape::ALL.len() as i32;
        let i = Shape::ALL.iter().position(|s| *s == self).unwrap_or(0) as i32;
        Shape::ALL[(i + steps).rem_euclid(n) as usize]
    }
}

/// A direction the player faces, as `arm` sends it.
pub fn face_name(f: Pos) -> &'static str {
    match f {
        Pos(0, 1, 0) => "up",
        Pos(0, -1, 0) => "down",
        Pos(1, 0, 0) => "east",
        Pos(-1, 0, 0) => "west",
        Pos(0, 0, -1) => "north",
        _ => "south",
    }
}
pub fn parse_face(text: &str) -> Option<Pos> {
    Some(match text {
        "up" => Pos(0, 1, 0),
        "down" => Pos(0, -1, 0),
        "east" => Pos(1, 0, 0),
        "west" => Pos(-1, 0, 0),
        "north" => Pos(0, 0, -1),
        "south" => Pos(0, 0, 1),
        _ => return None,
    })
}

/// The direction of a view (degrees as F3 shows them: yaw 0 looks south, 90 west; pitch -90 up):
/// straight up or down past 50 degrees, else the nearest of the four horizontal ones.
pub fn facing(yaw: f32, pitch: f32) -> Pos {
    if pitch < -50.0 {
        return Pos(0, 1, 0);
    }
    if pitch > 50.0 {
        return Pos(0, -1, 0);
    }
    match ((yaw / 90.0).round() as i32).rem_euclid(4) {
        0 => Pos(0, 0, 1),
        1 => Pos(-1, 0, 0),
        2 => Pos(0, 0, -1),
        _ => Pos(1, 0, 0),
    }
}

/// Where a player at `feet` mining `origin` is most likely facing, for a player without the
/// client half (whose view the server doesn't get).
pub fn guess_facing(origin: Pos, feet: (f64, f64, f64)) -> Pos {
    let dx = origin.0 as f64 + 0.5 - feet.0;
    let dy = origin.1 as f64 + 0.5 - (feet.1 + 1.62);
    let dz = origin.2 as f64 + 0.5 - feet.2;
    if dy.abs() > dx.abs() && dy.abs() > dz.abs() {
        Pos(0, dy.signum() as i32, 0)
    } else if dx.abs() > dz.abs() {
        Pos(dx.signum() as i32, 0, 0)
    } else {
        Pos(0, 0, dz.signum() as i32)
    }
}

fn block_id(state: &str) -> &str {
    state.split('[').next().unwrap_or(state)
}

/// What counts as the same block for a vein: an ore and its deepslate form, lit and unlit
/// redstone ore.
fn kind(state: &str) -> String {
    let id = block_id(state);
    match id.strip_prefix("minecraft:deepslate_") {
        Some(rest) if rest.ends_with("_ore") => format!("minecraft:{rest}"),
        _ => id.to_owned(),
    }
}

/// Never mined: air and fluids, unbreakable and technical blocks, and blocks that hold things.
pub fn kept(state: &str) -> bool {
    let id = block_id(state);
    matches!(
        id,
        "minecraft:air"
            | "minecraft:cave_air"
            | "minecraft:void_air"
            | "minecraft:water"
            | "minecraft:lava"
            | "minecraft:bedrock"
            | "minecraft:barrier"
            | "minecraft:light"
            | "minecraft:structure_void"
            | "minecraft:end_portal"
            | "minecraft:end_gateway"
            | "minecraft:end_portal_frame"
            | "minecraft:nether_portal"
            | "minecraft:command_block"
            | "minecraft:chain_command_block"
            | "minecraft:repeating_command_block"
            | "minecraft:structure_block"
            | "minecraft:jigsaw"
            | "minecraft:reinforced_deepslate"
            | "minecraft:spawner"
            | "minecraft:trial_spawner"
            | "minecraft:vault"
            | "minecraft:chest"
            | "minecraft:trapped_chest"
            | "minecraft:barrel"
            | "minecraft:shulker_box"
            | "minecraft:hopper"
            | "minecraft:dispenser"
            | "minecraft:dropper"
            | "minecraft:furnace"
            | "minecraft:blast_furnace"
            | "minecraft:smoker"
            | "minecraft:brewing_stand"
            | "minecraft:beacon"
            | "minecraft:crafter"
            | "minecraft:decorated_pot"
            | "minecraft:chiseled_bookshelf"
            | "minecraft:lectern"
            | "minecraft:jukebox"
    ) || id.ends_with("_shulker_box")
        || id.ends_with("_sign")
        || id.ends_with("_bed")
}

/// The blocks mined with `origin` (it excluded: the player mined it), nearest first, at most
/// `max_total` - 1. `forward` is the way the player faces; `get` reads a block, none where it
/// can't (an unloaded chunk is never reached into).
pub fn plan<F>(
    origin: Pos,
    original: &str,
    shape: Shape,
    max_total: usize,
    forward: Pos,
    mut get: F,
) -> Vec<Pos>
where
    F: FnMut(Pos) -> Option<String>,
{
    let room = max_total.clamp(1, MAX) - 1;
    if room == 0 || kept(original) {
        return Vec::new();
    }
    let mut out = Vec::new();
    if shape == Shape::Vein {
        let want = kind(original);
        let mut queue = VecDeque::from([origin]);
        let mut seen = BTreeSet::from([origin]);
        let mut dirs = Vec::with_capacity(26);
        for dx in -1..=1 {
            for dy in -1..=1 {
                for dz in -1..=1 {
                    if (dx, dy, dz) != (0, 0, 0) {
                        dirs.push(Pos(dx, dy, dz));
                    }
                }
            }
        }
        // Faces first, then edges, then corners.
        dirs.sort_by_key(|d| d.0.abs() + d.1.abs() + d.2.abs());
        while let Some(p) = queue.pop_front() {
            for &d in &dirs {
                if out.len() >= room || seen.len() >= 4096 {
                    return out;
                }
                let q = p.plus(d);
                if !q.near(origin) || !seen.insert(q) {
                    continue;
                }
                if let Some(state) = get(q)
                    && !kept(&state)
                    && kind(&state) == want
                {
                    out.push(q);
                    queue.push_back(q);
                }
            }
        }
        return out;
    }
    // The two directions across `forward`.
    let (a, b) = if forward.0 != 0 {
        (Pos(0, 1, 0), Pos(0, 0, 1))
    } else if forward.1 != 0 {
        (Pos(1, 0, 0), Pos(0, 0, 1))
    } else {
        (Pos(1, 0, 0), Pos(0, 1, 0))
    };
    let mut candidates = Vec::new();
    match shape {
        Shape::Plane | Shape::Tunnel => {
            let depth = if shape == Shape::Tunnel { 16 } else { 1 };
            for k in 0..depth {
                for i in -1..=1 {
                    for j in -1..=1 {
                        candidates.push(origin.plus(forward.times(k)).plus(a.times(i)).plus(b.times(j)));
                    }
                }
            }
        }
        Shape::Line => {
            for k in 1..MAX as i32 {
                candidates.push(origin.plus(forward.times(k)));
            }
        }
        Shape::StairsUp | Shape::StairsDown => {
            let rise = if shape == Shape::StairsUp { 1 } else { -1 };
            // Looking up or down, the stairs run the way of the block from the player.
            let ahead = if forward.1 != 0 { Pos(0, 0, 1) } else { forward };
            for step in 0..32 {
                // A step and the two blocks above it, for headroom.
                for head in 0..3 {
                    candidates.push(origin.plus(ahead.times(step)).plus(Pos(0, rise * step + head, 0)));
                }
            }
        }
        Shape::Vein => unreachable!(),
    }
    let mut seen = BTreeSet::new();
    for q in candidates {
        if out.len() >= room {
            break;
        }
        if q == origin || !q.near(origin) || !seen.insert(q) {
            continue;
        }
        if let Some(state) = get(q)
            && !kept(&state)
        {
            out.push(q);
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeMap;

    #[test]
    fn a_vein_is_its_own_kind_and_bounded() {
        let mut blocks = BTreeMap::new();
        for x in 1..=40 {
            blocks.insert(Pos(x, 64, 0), "minecraft:iron_ore".to_string());
        }
        blocks.insert(Pos(0, 65, 0), "minecraft:stone".into());
        blocks.insert(Pos(-1, 64, 0), "minecraft:deepslate_iron_ore".into());
        let got = plan(Pos(0, 64, 0), "minecraft:iron_ore", Shape::Vein, 64, Pos(0, 0, 1), |p| {
            blocks.get(&p).cloned()
        });
        // 16 along +x within reach, and the deepslate form beside it; no stone.
        assert_eq!(got.len(), 17);
        assert!(got.contains(&Pos(-1, 64, 0)));
        assert!(!got.contains(&Pos(0, 65, 0)));
        let limited = plan(Pos(0, 64, 0), "minecraft:iron_ore", Shape::Vein, 5, Pos(0, 0, 1), |p| {
            blocks.get(&p).cloned()
        });
        assert_eq!(limited.len(), 4);
    }

    #[test]
    fn diagonals_join_a_vein() {
        let diagonal = Pos(1, 65, 1);
        let got = plan(Pos(0, 64, 0), "minecraft:emerald_ore", Shape::Vein, 64, Pos(0, 0, 1), |p| {
            (p == diagonal).then(|| "minecraft:emerald_ore".into())
        });
        assert_eq!(got, vec![diagonal]);
    }

    #[test]
    fn shapes_face_the_way_the_player_looks() {
        let stone = |_| Some("minecraft:stone".to_string());
        // A plane across a block mined facing north: x and y vary, z doesn't.
        let plane = plan(Pos(0, 64, 0), "minecraft:stone", Shape::Plane, 64, Pos(0, 0, -1), stone);
        assert_eq!(plane.len(), 8);
        assert!(plane.iter().all(|p| p.2 == 0));
        // A tunnel facing east, cut by the limit.
        let tunnel = plan(Pos(0, 64, 0), "minecraft:stone", Shape::Tunnel, 64, Pos(1, 0, 0), stone);
        assert_eq!(tunnel.len(), 63);
        assert!(tunnel.iter().all(|p| p.0 >= 0 && (p.1 - 64).abs() <= 1 && p.2.abs() <= 1));
        let line = plan(Pos(0, 64, 0), "minecraft:stone", Shape::Line, 10, Pos(0, -1, 0), stone);
        assert_eq!(line, (1..10).map(|k| Pos(0, 64 - k, 0)).collect::<Vec<_>>());
        assert!(!plan(Pos(0, 0, 0), "minecraft:stone", Shape::Line, 64, Pos(1, 0, 0), stone)
            .contains(&Pos(0, 0, 0)));
    }

    #[test]
    fn kept_blocks_stay() {
        let got = plan(Pos(0, 64, 0), "minecraft:stone", Shape::Plane, 64, Pos(0, 0, 1), |p| {
            Some(if p.0 == 1 { "minecraft:chest[facing=north]" } else { "minecraft:stone" }.into())
        });
        assert!(got.iter().all(|p| p.0 != 1));
        assert!(plan(Pos(0, 0, 0), "minecraft:bedrock", Shape::Vein, 64, Pos(0, 0, 1), |_| None).is_empty());
        assert!(plan(Pos(0, 0, 0), "minecraft:stone", Shape::Vein, 1, Pos(0, 0, 1), |_| None).is_empty());
    }

    #[test]
    fn views_and_shapes_round_trip() {
        assert_eq!(facing(0.0, 0.0), Pos(0, 0, 1));
        assert_eq!(facing(90.0, 10.0), Pos(-1, 0, 0));
        assert_eq!(facing(-90.0, 0.0), Pos(1, 0, 0));
        assert_eq!(facing(179.0, 0.0), Pos(0, 0, -1));
        assert_eq!(facing(30.0, -80.0), Pos(0, 1, 0));
        for f in [Pos(0, 1, 0), Pos(0, -1, 0), Pos(1, 0, 0), Pos(-1, 0, 0), Pos(0, 0, 1), Pos(0, 0, -1)] {
            assert_eq!(parse_face(face_name(f)), Some(f));
        }
        assert_eq!(Shape::Vein.step(-1), Shape::StairsDown);
        assert_eq!(Shape::StairsDown.step(1), Shape::Vein);
        for s in Shape::ALL {
            assert_eq!(Shape::parse(s.name()), Some(s));
        }
    }
}
