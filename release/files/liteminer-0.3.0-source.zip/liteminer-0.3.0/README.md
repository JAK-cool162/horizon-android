# LiteMiner H 0.3 (Horizon Android .hmod)

Vein mining for Horizon as two sandboxed mods. They load without rebuilding the game:
Mods > Import file, turn them on. Needs mod API level 10 (Horizon Android dev 1016 or later).

- `liteminer.hmod`: the server half. It mines the blocks, as you.
- `liteminer_client.hmod`: the client half. Keys, outlines and the cost panel.

In single player both run on your phone. On a server, the server needs `liteminer.hmod` and
you need `liteminer_client.hmod`.

## Use

- **Hold Left Alt** and look at a block. The blocks that would come down with it are
  outlined, and a panel shows what it costs:
  - **Blocks**: how many, out of the limit.
  - **Hunger**: food points (vanilla's 0.005 exhaustion per block).
  - **Durability**: tool uses. `(~)` marks an average with Unbreaking. It turns red with
    "Breaks after N blocks" when your tool won't last.
- Mine the block while holding: the outlined blocks come down too. They're mined as you
  would mine them: your tool's Fortune and Silk Touch, one durability use per block,
  hunger and statistics. Mining stops when the tool breaks.
- **Scroll while holding** to switch the shape: Vein (the connected blocks of the same kind,
  diagonals included, deepslate ores with their ore), 3x3 plane, 3x3 tunnel, Line, Stairs
  up, Stairs down. The plane, tunnel, line and stairs face the way you look.
- The **Next shape** key (default `` ` ``) switches it too.
- Up to **64 blocks** by default.

### On a phone

Open the touch controls editor (**Controls** beside Launch in the launcher, or in-game from
Options), add a button, then pick its key under **Game action**. Choose `LiteMiner H Client: Hold to vein mine`, and another button for
`LiteMiner H Client: Next shape`. In Tap mode (Settings), a tap turns it on and another
tap turns it off.

## Settings

Options > Mods > LiteMiner H Client > Settings:

- Shape and block limit (8 to 64).
- Activation: hold the key, or tap on and tap off.
- Outline: through blocks, visible faces only, or off.
- Outline colour.
- Where the stats panel sits, or off.

The keys are on the same page.

Without the client half, `/lite` turns it on for you (`/lite mode ...`, `/lite limit
1-64`, `/lite status`). The shape's direction is then guessed from where you stand.

## Never mined

Air, fluids, bedrock, barriers, portals, command, structure and jigsaw blocks, spawners,
vaults, beds, signs, and every container (chests, barrels, shulker boxes, furnaces,
hoppers...). Game mode, spawn protection and the server's native mods' rules apply as they
do to your own mining.

## Build

    rustup target add wasm32-unknown-unknown
    cargo install --locked --git https://github.com/JAK-cool162/horizon-android --branch android cargo-horizon-mod
    cd server && cargo test && cargo horizon-mod test && cargo horizon-mod build
    cd ../client && cargo test && cargo horizon-mod test && cargo horizon-mod build

Inspired by Kaf's Liteminer (MIT, see LICENSE-LITEMINER).
