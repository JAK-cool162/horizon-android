//! LiteMiner H, server half: what it mines. A player arms it by holding the client half's key
//! (it sends `/lite arm <shape> <limit> <face>` every half second while held, and `/lite disarm`
//! on release), or turns it on with `/lite` without the client half. A block they then break
//! brings down the blocks the planner picks, mined as them with `world::mine_blocks`: their
//! tool's loot (Fortune, Silk Touch), a durability use per block, vanilla's exhaustion.
#[path = "../../shared/planner.rs"]
mod planner;
use horizon_mod_sdk::server::{players, world, Args, BlockPos, Player, Registration, ServerMod};
use horizon_mod_sdk::storage;
use planner::{guess_facing, parse_face, plan, Pos, Shape, MAX};
use std::collections::BTreeMap;

const KEY: &str = "players";
/// An arm lasts this long without the client half's next one (it sends one every 10 ticks):
/// a key-up lost with a dropped connection disarms by itself.
const ARM_TICKS: u64 = 40;

#[derive(Clone, Copy, Debug, PartialEq)]
struct Settings {
    on: bool,
    shape: Shape,
    limit: u32,
}
impl Default for Settings {
    fn default() -> Self {
        Settings { on: false, shape: Shape::Vein, limit: MAX as u32 }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
struct Armed {
    shape: Shape,
    limit: u32,
    forward: Pos,
    until: u64,
}

/// `id on|off shape limit`, a line a player.
fn read(text: &str) -> BTreeMap<String, Settings> {
    text.lines()
        .filter_map(|line| {
            let mut w = line.split_whitespace();
            let id = w.next()?.to_owned();
            let on = w.next()? == "on";
            let shape = Shape::parse(w.next()?)?;
            let limit = w.next()?.parse::<u32>().ok()?.clamp(1, MAX as u32);
            Some((id, Settings { on, shape, limit }))
        })
        .collect()
}

fn write(all: &BTreeMap<String, Settings>) -> String {
    all.iter()
        .map(|(id, s)| {
            let on = if s.on { "on" } else { "off" };
            format!("{id} {on} {} {}\n", s.shape.name(), s.limit)
        })
        .collect()
}

fn status(s: &Settings) -> String {
    let state = if s.on { "ON" } else { "OFF" };
    format!(
        "LiteMiner {state}: {}, up to {} blocks (/lite to turn it {})",
        s.shape.label(),
        s.limit,
        if s.on { "off" } else { "on" }
    )
}

const HELP: &str = "/lite: on or off | /lite mode vein|plane|tunnel|line|stairsup|stairsdown | \
                    /lite limit 1-64 | /lite status. With the client half: hold Left Alt and mine.";

#[derive(Default)]
struct LiteMiner {
    players: BTreeMap<String, Settings>,
    armed: BTreeMap<String, Armed>,
    now: u64,
}

impl LiteMiner {
    fn save(&self) {
        if let Err(e) = storage::set(KEY, write(&self.players).as_bytes()) {
            horizon_mod_sdk::warn(&format!("LiteMiner: settings not saved: {e}"));
        }
    }
    /// `arm <shape> <limit> <face>` from the client half.
    fn arm(&mut self, player: &Player, words: &[&str]) -> Result<(), String> {
        let [shape, limit, face] = words else {
            return Err("arm <shape> <limit> <face>".into());
        };
        let shape = Shape::parse(shape).ok_or("unknown shape")?;
        let limit = limit.parse::<u32>().map_err(|_| "bad limit")?.clamp(1, MAX as u32);
        let forward = parse_face(face).ok_or("unknown face")?;
        self.armed.insert(
            player.id.clone(),
            Armed { shape, limit, forward, until: self.now + ARM_TICKS },
        );
        Ok(())
    }
}

impl ServerMod for LiteMiner {
    fn init() -> Result<(Self, Registration), String> {
        let saved = storage::get(KEY).unwrap_or_default();
        let players = read(&String::from_utf8_lossy(&saved));
        Ok((
            LiteMiner { players, ..Default::default() },
            Registration::new().command("lite").on_blocks().on_joins().on_tick(),
        ))
    }

    fn tick(&mut self, tick: u64) {
        self.now = tick;
        self.armed.retain(|_, a| a.until >= tick);
    }

    /// A reminder when `/lite` is still on from last time.
    fn player_joined(&mut self, player: &Player) {
        if let Some(s) = self.players.get(&player.id).filter(|s| s.on) {
            players::tell(&player.id, &status(s));
        }
    }

    fn player_left(&mut self, player: &Player) {
        self.armed.remove(&player.id);
    }

    fn command(&mut self, player: &Player, _name: &str, args: &Args) -> Result<Option<String>, String> {
        let words: Vec<&str> = args.text().split_whitespace().collect();
        // The client half's, said nothing about in the chat.
        match words.as_slice() {
            ["arm", rest @ ..] => return self.arm(player, rest).map(|()| None),
            ["disarm"] => {
                self.armed.remove(&player.id);
                return Ok(None);
            }
            _ => {}
        }
        let s = self.players.entry(player.id.clone()).or_default();
        match words.as_slice() {
            [] => s.on = !s.on,
            ["on"] => s.on = true,
            ["off"] => s.on = false,
            ["status"] => return Ok(Some(status(s))),
            ["help"] => return Ok(Some(HELP.into())),
            ["mode", m] => {
                s.shape = Shape::parse(m).ok_or("Shapes: vein, plane, tunnel, line, stairsup, stairsdown")?
            }
            ["limit", n] => {
                let n: u32 = n.parse().map_err(|_| "Use /lite limit 1-64".to_string())?;
                if !(1..=MAX as u32).contains(&n) {
                    return Err("The limit is 1 to 64 blocks, the one you mine included".into());
                }
                s.limit = n;
            }
            _ => return Err(HELP.into()),
        }
        let text = status(s);
        self.save();
        Ok(Some(text))
    }

    fn block_broken(&mut self, player: &Player, pos: BlockPos, state: &str) {
        let origin = Pos(pos.x, pos.y, pos.z);
        let (shape, limit, forward) = match self.armed.get(&player.id) {
            Some(a) if a.until >= self.now => (a.shape, a.limit, a.forward),
            _ => match self.players.get(&player.id).filter(|s| s.on) {
                Some(s) => (s.shape, s.limit, guess_facing(origin, (player.x, player.y, player.z))),
                None => return,
            },
        };
        let dimension = &player.dimension;
        let extra = plan(origin, state, shape, limit as usize, forward, |p| {
            world::get_block(dimension, p.0, p.1, p.2)
        });
        if extra.is_empty() {
            return;
        }
        let positions: Vec<(i32, i32, i32)> = extra.iter().map(|p| (p.0, p.1, p.2)).collect();
        if let Err(e) = world::mine_blocks(&player.id, &positions) {
            horizon_mod_sdk::warn(&format!("LiteMiner: {e}"));
        }
    }
}

horizon_mod_sdk::export_server_mod!(LiteMiner);

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn settings_survive_storage() {
        let mut all = BTreeMap::new();
        all.insert("a-b".to_string(), Settings { on: true, shape: Shape::Tunnel, limit: 12 });
        all.insert("c".to_string(), Settings::default());
        assert_eq!(read(&write(&all)), all);
        // A bad line is skipped, a limit past 64 clamped.
        assert_eq!(read("x on nonsense 3\ny off vein 900\n")["y"].limit, 64);
        assert!(!read("x on nonsense 3\n").contains_key("x"));
    }
}
